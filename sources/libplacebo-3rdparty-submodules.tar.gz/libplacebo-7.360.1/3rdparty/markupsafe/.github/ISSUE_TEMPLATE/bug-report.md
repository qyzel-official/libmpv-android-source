---
name: Bug report
about: Report a bug in MarkupSafe (not other projects which depend on MarkupSafe)
---

<!--
This issue tracker is a tool to address bugs in MarkupSafe itself. Please use
GitHub Discussions or the Pallets Discord for questions about your own code.

Replace this comment with a clear outline of what the bug is.
-->

<!--
Describe how to replicate the bug.

Include a minimal reproducible example that demonstrates the bug.
Include the full traceback if there was an exception.
-->

<!--
Describe the expected behavior that should have happened but didn't.
-->

Environment:

- Python version:
- MarkupSafe version:
